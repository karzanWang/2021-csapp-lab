/* 王海伟 19302010011
 *
 *  Free block
 *  [ HEADER | PREV | NEXT |    PAYLOAD    | FOOTER ]
 *  Allocated block
 *  [ HEADER |   PAYLOAD    | FOOTER ]
 *   
 *  Free List Structure
 *  [NULL  <==  Free 1 <==> Free 2 <==> Free3 <==> ... <==> FreeN ==> NULL]
 * 
 * 没有使用分离链表。。。。。不知道什么会爆内存。。。。。。
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#define checkheap mm_checkheap
#endif /* def DRIVER */


/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
/* #define DEBUG  */
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* Basic constants and macros */
#define WSIZE       4       /* Word and header/footer size (bytes) */ 
#define DSIZE       8       /* Double word size (bytes) */
#define CHUNKSIZE  (1<<8)  /* Extend heap by this amount (bytes) */  
#define ALIGNMENT 8         /* single word (4) or double word (8) alignment */
#define MINIMUM   24

#define MAX(x, y) ((x) > (y)? (x) : (y))
/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)

/* Pack a size and allocated bit into a word */
#define PACK(size, alloc)  ((size) | (alloc))

/* Read and write a word at address p */
#define GET(p)       (*(unsigned int *)(p))
#define PUT(p, val)  (*(unsigned int *)(p) = (val))

/* Read the size and allocated fields from address p */
#define GET_SIZE(p)  (GET(p) & ~0x7)
#define GET_ALLOC(p) (GET(p) & 0x1)

/* Given block ptr ptr, compute address of its header and footer */
#define HDRP(ptr)       ((char *)(ptr) - WSIZE)
#define FTRP(ptr)       ((char *)(ptr) + GET_SIZE(HDRP(ptr)) - DSIZE)

/* Given block ptr ptr, compute address of next and previous blocks */
#define NEXT_BLKP(ptr)  ((char *)(ptr) + GET_SIZE(HDRP(ptr)))
#define PREV_BLKP(ptr)  ((char *)(ptr) - GET_SIZE(HDRP(ptr) - WSIZE))

/* Given free list ptr, compute address of next and previous free list ptrs */
#define NEXT_FREEP(ptr)  (*(char **)((char *)(ptr) + DSIZE))
#define PREV_FREEP(ptr)  (*(char **)((char * )(ptr)))

/* Global variables */
static char *heap_listp = 0;  /* Pointer to first block */
static char *free_listp = 0;   /* Pointer to list to list of free blocks */ 

/* Function prototypes for internal helper routines */
static void *extend_heap(size_t words);
static void place(void *ptr, size_t asize);
static void *find_fit(size_t asize);
static void *coalesce(void *ptr);
static void print_chunk(void *ptr);
static void check_chunk(void *ptr);
static void insert_free_chunk(void *ptr);
static void remove_free_chunk(void *ptr);
static int free_list_edge(void *ptr);
/*
 * Initialize memory manager: return -1 on error, 0 on success.
 * Memory is essentially one huge block that is in free list. 
 */
int mm_init(void) {

    /* Create the initial empty heap(free list) */
    if ((heap_listp = mem_sbrk(2*MINIMUM)) == (void *)-1) 
        return -1;
    PUT(heap_listp, 0);                          /* Alignment padding */
    PUT(heap_listp + (1*WSIZE), PACK(MINIMUM, 1)); /* Prologue header */ 
    PUT(heap_listp + (2*WSIZE), 0); /* Previous pointer */
    PUT(heap_listp + (3*WSIZE), 0);    /* Next Pointer */

    PUT(heap_listp + MINIMUM, PACK(MINIMUM, 1));      /* Prologue footer */
    PUT(heap_listp + MINIMUM + WSIZE, PACK(0, 1));    /* Epilogue Header */

    free_listp = heap_listp + DSIZE;

    /* Extend the empty heap with a free block of CHUNKSIZE bytes */
    if (extend_heap(CHUNKSIZE/WSIZE) == NULL) 
        return -1;

    return 0;
}

/*
 * malloc - Allocate a block with at least size bytes of payload
 */
void *malloc (size_t size) {
    size_t asize;      /* Adjusted block size */
    size_t extendsize; /* Amount to extend heap if no fit */
    char *ptr;  

    if (heap_listp == 0){
        mm_init();
    }

    if (size == 0)
        return NULL;

    asize = MAX(ALIGN(size) + DSIZE, MINIMUM);

    /* Search for a fit */
    if ((ptr = find_fit(asize)) != NULL) {  
        place(ptr, asize);       
        return ptr;
    }

    /* No fit found. */
    extendsize = MAX(asize,CHUNKSIZE);                 
    if ((ptr = extend_heap(extendsize/WSIZE)) == NULL)  
        return NULL;                                  
    place(ptr, asize);                                 

    return ptr;
}

/*
 * free - Free a block
 */
void free (void *ptr) {

    if (ptr == 0) 
        return;

    size_t size = GET_SIZE(HDRP(ptr));
    if (heap_listp == 0){
        mm_init();
    }

    /* Set header, footer alloc bits to zero */
    PUT(HDRP(ptr), PACK(size, 0));
    PUT(FTRP(ptr), PACK(size, 0));

    coalesce(ptr);
}

/*
 * realloc - Naive implementation of realloc
 */
void *realloc(void *ptr, size_t size) {
    size_t oldsize, asize;
    void *newptr;

    asize = MAX(ALIGN(size) + DSIZE, MINIMUM);
    /* just free */
    if(size == 0) {
        free(ptr);
        return 0;
    }

    /* malloc. */
    if(ptr == NULL) {
        return malloc(size);
    }

    /* Original block size */
    oldsize = GET_SIZE(HDRP(ptr));

    /* If new size is same as old, just return */
    if (asize == oldsize)  return ptr;

    newptr = mm_malloc(size);

    /* If realloc() fails the original block is left untouched  */
    if(!newptr) {
        return 0;
    }

    /* Copy the old data. */
    if(size < oldsize) oldsize = size;
    memcpy(newptr, ptr, oldsize);

    /* Free the old block. */
    free(ptr);

    return newptr;
}

/*
 * calloc - Allocate the block and set it to zero
 *
 */
void *calloc (size_t nmemb, size_t size) {
    size_t bytes = nmemb * size;
    void *newptr;

    newptr = malloc(bytes);
    memset(newptr, 0, bytes);

    return newptr;
}


/*
 * Return whether the pointer is in the heap.
 * Useful in debugging.
 */
static int in_heap(const void *p) {
    return p <= mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * Useful in debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/* 
 * mm_checkheap - 
 * 遍历所有chunk，检查coalesc和Prologue，和check_chunk函数检查，统计free的chunk的数量
 * 然后检查free list，检查bounds和Next/Prev Consistency，以及统计里面chunk的数量，做对比
 */
void mm_checkheap(int lineno) {
    void *ptr;
    int numfree1 = 0, numfree2 = 0;     /* Count free blocks */
    ptr = heap_listp;                   /* Start from the first block address */

    /* Check prologue */ 
    if ((GET_SIZE(HDRP(ptr)) != MINIMUM) || (GET_ALLOC(HDRP(ptr)) != 1)) {
        printf("Addr: %p - ** Prologue Error** \n", ptr);
        assert(0);
    }
    ptr = NEXT_BLKP(ptr);

    /* Iterating through entire heap. Convoluted code checks that
     * we are not at the epilogue. Loops thr and checks epilogue block! */
    while (!((GET_SIZE(HDRP(ptr)) == 0) && (GET_ALLOC(HDRP(ptr)) == 1))) {

        /* Perform all checks done on block */
        check_chunk(ptr);
        /* Check coalescing: If alloc bit of current and next block is 0 */
        if (!(GET_ALLOC(HDRP(ptr)) || GET_ALLOC(HDRP(NEXT_BLKP(ptr))))) {
            printf("Addr: %p - ** Coalescing Error** \n", ptr);
            assert(0);
        }

        /* Count number of free blocks */
        if(!(GET_ALLOC(HDRP(ptr))))
            numfree1++;

        ptr = NEXT_BLKP(ptr);
    }

    /* Heap Check for explicit list */ 
    ptr = free_listp;     

    /* If our free list is empty, nothing to check */
    if (ptr == 0) {
        return;
    }

    /* Iterating through free list */ 
    while (ptr != NULL) {
        if (!free_list_edge(ptr)) {
            /* All next/prev pointers are consistent */
            if (PREV_FREEP(NEXT_FREEP(ptr)) != NEXT_FREEP(PREV_FREEP(ptr))) {
                printf("Addr: %p - ** Next/Prev Consistency Error ** \n", ptr);
                assert(0);
            }
        }
        /* Free List bounds check */ 
        if (!in_heap(ptr)) {
            printf("Addr: %p - ** Free List Out of bounds** \n", ptr);
            assert(0);
        }
        numfree2++; 
        ptr = NEXT_FREEP(ptr);
    }

    if (numfree1 != numfree2) {
        printf(" Error: - ** %d Free List Count %d ** \n", numfree1, numfree2);
        assert(0);
    }
}


/* 
 * extend_heap - Extend heap with free block and return its block pointer
 */
static void *extend_heap(size_t words) 
{
    char *ptr;
    size_t size;

    /* Allocate an even number of words to maintain alignment */
    size = (words % 2) ? (words+1) * WSIZE : words * WSIZE; 
    if (size < MINIMUM)
        size = MINIMUM;
    if ((long)(ptr = mem_sbrk(size)) == -1)  
        return NULL;                                        

    /* Initialize free block header/footer and the epilogue header */
    PUT(HDRP(ptr), PACK(size, 0));         /* Free block header */   
    PUT(FTRP(ptr), PACK(size, 0));         /* Free block footer */   
    PUT(HDRP(NEXT_BLKP(ptr)), PACK(0, 1)); /* New epilogue header */ 

    /* Coalesce if the previous block was free */
    return coalesce(ptr);                                          
}

/*
 * coalesce - Boundary tag coalescing. Returns ptr to coalesced block
 */
static void *coalesce (void *ptr) 
{
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(ptr)));
    /* When at front, prev block is same as curr block*/
    if (PREV_BLKP(ptr) == ptr )
        prev_alloc = 1;

    size_t next_alloc = GET_ALLOC(HDRP(NEXT_BLKP(ptr)));
    size_t size = GET_SIZE(HDRP(ptr));

    /* Case  1 no op */ 

    if (prev_alloc && !next_alloc) {      /* Case 2 */
        size += GET_SIZE(HDRP(NEXT_BLKP(ptr)));
        remove_free_chunk(NEXT_BLKP(ptr));
        PUT(HDRP(ptr), PACK(size, 0));
        PUT(FTRP(ptr), PACK(size,0));
    }

    else if (!prev_alloc && next_alloc) {      /* Case 3 */
        size += GET_SIZE(HDRP(PREV_BLKP(ptr)));
        remove_free_chunk(PREV_BLKP(ptr));
        PUT(FTRP(ptr), PACK(size, 0));
        PUT(HDRP(PREV_BLKP(ptr)), PACK(size, 0));
        ptr = PREV_BLKP(ptr);
    }

    else if (!prev_alloc && !next_alloc){      /* Case 4 */
        size += GET_SIZE(HDRP(PREV_BLKP(ptr))) + 
            GET_SIZE(FTRP(NEXT_BLKP(ptr)));
        remove_free_chunk(NEXT_BLKP(ptr));           
        remove_free_chunk(PREV_BLKP(ptr));
        PUT(HDRP(PREV_BLKP(ptr)), PACK(size, 0));
        PUT(FTRP(NEXT_BLKP(ptr)), PACK(size, 0));
        ptr = PREV_BLKP(ptr);
    }

    insert_free_chunk(ptr);       

    return ptr;
}

/* 
 * place - Place block of asize bytes at start of free block bp 
 *         and split if remainder would be at least minimum block size
 */
static void place(void *ptr, size_t asize)
{
    size_t csize = GET_SIZE(HDRP(ptr));   


    if ((csize - asize) >= (MINIMUM)) { 
        PUT(HDRP(ptr), PACK(asize, 1));
        PUT(FTRP(ptr), PACK(asize, 1));
        remove_free_chunk(ptr);
        ptr = NEXT_BLKP(ptr);
        PUT(HDRP(ptr), PACK(csize-asize, 0));
        PUT(FTRP(ptr), PACK(csize-asize, 0));
        coalesce(ptr);
    }
    else { 
        PUT(HDRP(ptr), PACK(csize, 1));
        PUT(FTRP(ptr), PACK(csize, 1));
        remove_free_chunk(ptr);
    }

}

/* 
 * find_fit - Find a fit for a block with asize bytes
 *            Iterate over free list until we get 
 *            free block >= requested asize
 */
static void *find_fit (size_t asize)
{
    /* First-fit search */
    void *ptr;

    /* Iterate over free list till we find the first block that fits */
    for (ptr = free_listp; ptr != NULL; ptr = NEXT_FREEP(ptr)) {
        if (!GET_ALLOC(HDRP(ptr)) && (asize <= GET_SIZE(HDRP(ptr)))) {
            return ptr;
        }
    }
    return NULL; /* No fit */
}

static void print_chunk(void *ptr)  {
    size_t hsize, fsize;
    size_t halloc, falloc;
    hsize = GET_SIZE(HDRP(ptr));
    fsize = GET_SIZE(FTRP(ptr));
    halloc = GET_ALLOC(HDRP(ptr));
    falloc = GET_ALLOC(FTRP(ptr));

    if (ptr == NULL ) {
        printf("Error: Null Pointer Address!! \n");
        return;
    }
    printf("Addr: %p, Hdr: [%zu:%c], Ftr: [%zu:%c] \n",
            ptr, hsize, (halloc ? 'a':'f'), fsize, (falloc ? 'a':'f'));
    if (hsize == 0 && halloc == 1)
        printf("Addr: %p - EOF Block \n", ptr); 
}



/* 
 * check_chunk - check block header and footer. 
 */
static void check_chunk(void *ptr)  {
    /* Check each block's address alignment */
    if (!aligned(ptr)) {
        printf("Addr: %p - ** Block Alignment Error** \n", ptr);
        assert(0);
    }
    /* Each block's bounds check */ 
    if (!in_heap(ptr)) {
        printf("Addr: %p - ** Out of Heap Bounds Error** \n", ptr);
        assert(0);
    }
    /* Check Minimum size */
    if (GET_ALLOC(HDRP(ptr))) {
        if (GET_SIZE(HDRP(ptr)) < (2*DSIZE)) {
            printf("Addr: %p - ** Min Size Error ** \n", ptr);
            assert(0);
        }
    }
    /* Header/Footer Alignmment */
    if (GET_SIZE(HDRP(ptr)) % ALIGNMENT)  {
        printf("Addr: %p - ** Header Not double word aligned** \n", ptr);
        assert(0);
    }

    /* Check header: footer match */
    if ((GET_SIZE(HDRP(ptr)) != GET_SIZE(FTRP(ptr))) ||
            (GET_ALLOC(HDRP(ptr)) != GET_ALLOC(FTRP(ptr)))) {
        printf("Addr: %p - ** Header Footer mismatch** \n", ptr);
        print_chunk(ptr);
        assert(0);
    }

}


static void insert_free_chunk(void *ptr) {
    /* If free list has nothing*/ 
    if (free_listp == NULL) {
        NEXT_FREEP(ptr) = NULL;
        PREV_FREEP(ptr) = NULL;
        free_listp = ptr;
        return;
    }

    PREV_FREEP(ptr) = NULL;
    NEXT_FREEP(ptr) = free_listp;       /* Set curr next to head of list */
    PREV_FREEP(free_listp) = ptr;                

    free_listp = ptr;                   /* curr ptr is now head of list */
}


/* 
 * CASE 1: Remove block with only one block in the list
 * CASE 2: Block is top of list: Set next block as new top. 
 * CASE 3: Block is end of free list: Set prev block as new end
 * CASE 4: Freed block is a middle one: Link Prev block to next block
 *
 */
static void remove_free_chunk(void *ptr) {
    /* Case when we have nothing in list */
    if (free_listp == 0)
        return;


    /* Case 1 */
    if ((PREV_FREEP(ptr) == NULL) && (NEXT_FREEP(ptr) == NULL)) {
        free_listp = 0;
    }

    /* Case 2 */
    else if ((PREV_FREEP(ptr) == NULL) && (NEXT_FREEP(ptr) != NULL)) {
        free_listp = NEXT_FREEP(ptr);
        PREV_FREEP(free_listp) = NULL;  
    }

    /* Case 3 */
    else if ((PREV_FREEP(ptr) != NULL) && (NEXT_FREEP(ptr) == NULL)) {
        /* Last one now points to NULL */
        NEXT_FREEP(PREV_FREEP(ptr)) = NULL; 
    }

    /* Case 4 */
    else if ((PREV_FREEP(ptr) != NULL) && (NEXT_FREEP(ptr) != NULL)) {
        PREV_FREEP(NEXT_FREEP(ptr)) = PREV_FREEP(ptr);  
        NEXT_FREEP(PREV_FREEP(ptr)) = NEXT_FREEP(ptr); 
    }

}


/* 
 * free_list_edge - Returns 1 when free list ptr is at edge of list. 
 *                This check is used to handle edge conditions in check_chunk. 
 */
static int free_list_edge(void *ptr) {
    return ((NEXT_FREEP(ptr) == NULL) || (PREV_FREEP(ptr) == NULL));
}